export class Cart {
  constructor(item, quantity) {
    this.item = item;
    this.quantity = quantity;
  }
}
