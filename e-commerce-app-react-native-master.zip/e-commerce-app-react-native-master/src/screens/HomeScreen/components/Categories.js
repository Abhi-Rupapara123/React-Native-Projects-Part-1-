export const categories = [
  {
    name: "Vòng Thạch Anh",
    bg: require("../../../assets/Images/bg1.jpg"),
  },
  {
    name: "Nhẫn Đá Quý",
    bg: require("../../../assets/Images/bg2.jpg"),
  },
  {
    name: "Đá Ruby",
    bg: require("../../../assets/Images/bg3.jpg"),
  },
];
