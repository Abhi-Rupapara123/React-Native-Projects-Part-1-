// API URL
export const API_URL = "https://e-commerce-ct-backend.herokuapp.com/api/v1";
export const secretKey = "Drmhze6EPcv0fN_81Bj-nAq241aA1";
export const STRIPE_PUBLISHABLE_KEY =
  "pk_test_51HLo2AD28q5Rme0eq3Q6J16dQEa0d38VoeY6ZJu8u3m1jzKcswvDmNkrNn6CqSCLv38tBNwdOOOKvLylPAPNYSpq00Vs0wQ3SV";
