import {
   Ironman, Captainamerica,
  Spiderman, Wolverine,Cyclops
} from "../resources";
export const users = [
    {
      "uid": "superhero1",
      "name": "Iron Man",
      "avatar": Ironman
    },
    {
      "uid": "superhero2",
      "name": "Captain America",
      "avatar": Captainamerica
    },
    {
      "uid": "superhero3",
      "name": "Spiderman",
      "avatar": Spiderman
    },
    {
      "uid": "superhero4",
      "name": "Wolverine",
      "avatar": Wolverine
    },
    {
      "uid": "superhero5",
      "name": "Cyclops",
      "avatar": Cyclops
    }
]

