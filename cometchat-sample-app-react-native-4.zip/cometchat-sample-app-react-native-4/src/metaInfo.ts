export const metaInfo = {
    name:"cometchat-chat-sample-app-react-native",
    version:"4.0.1",
    type:"sample",
    platform:"React Native"
}