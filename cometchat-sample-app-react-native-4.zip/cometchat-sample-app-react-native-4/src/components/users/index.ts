import { UserModuleList } from "./UserModuleList";
import { Details } from "./Details";