export const AppConstants = {
    APP_ID: 'xxxxxxxxxxxxx', // Enter your App ID
    REGION: 'xx', // Enter your App Region
    AUTH_KEY: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', // Enter your App Auth Key
}