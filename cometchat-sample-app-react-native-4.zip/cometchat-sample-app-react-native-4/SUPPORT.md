# Getting Support

The quickest way to get support is to contact us via your CometChat Pro Dashboard.
